#pragma once

class Number
{
private:
    double value;
public:
    Number(double value_ = 0);
    Number(const Number& other);
    ~Number();

    double getValue() const;

    void print() const;

    static const Number ZERO;
    static const Number ONE;

    Number operator+(const Number& other) const;
    Number operator-(const Number& other) const;
    Number operator*(const Number& other) const;
    Number operator/(const Number& other) const;

    Number& operator+=(const Number& other);
    Number& operator-=(const Number& other);
    Number& operator*=(const Number& other);
    Number& operator/=(const Number& other);

    bool operator==(const Number& other) const;
    bool operator>(const Number& other) const;
    bool operator<(const Number& other) const;
    bool operator!=(const Number& other) const;

    static Number sqrt(const Number number);
    static Number atan(const Number number);

    static Number create(const double value_);
};
