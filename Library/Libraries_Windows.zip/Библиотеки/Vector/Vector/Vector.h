#pragma once

#ifdef VECTOR_EXPORTS
#define VECTOR_API __declspec(dllexport)
#else
#define VECTOR_API __declspec(dllimport)
#endif

#include "Number.h"

class VECTOR_API Vector {
private:
	Number x, y;
public:
	Vector(Number x_, Number y_);
	Vector(const Vector& other);
	~Vector();

	static const Vector ZERO;
	static const Vector ONE;

	Number getX() const;
	Number getY() const;

	Number getPolarRadius() const;
	Number getPolarAngle() const;

	void print() const;

	Vector operator+(const Vector& other) const;
};