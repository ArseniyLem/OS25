#include "pch.h"
#include "Vector.h"
#include <iostream>

Vector::Vector(Number x_, Number y_) : x(x_), y(y_) {}
Vector::Vector(const Vector& other) : x(other.getX()), y(other.getY()) {}
Vector::~Vector() = default;

const Vector Vector::ZERO(0.0, 0.0);
const Vector Vector::ONE(1.0, 1.0);

Number Vector::getX() const { return this->x; }
Number Vector::getY() const { return this->y; }

Number Vector::getPolarRadius() const { return Number::sqrt(this->x * this->x + this->y * this->y); }
Number Vector::getPolarAngle() const { return Number::atan(this->x / this->y); }

void Vector::print() const {
	std::cout << "(" << this->x.getValue() << ", " << this->y.getValue() << ")";
}

Vector Vector::operator+(const Vector& other) const { return Vector(this->x + other.getX(), this->y + other.getY()); }