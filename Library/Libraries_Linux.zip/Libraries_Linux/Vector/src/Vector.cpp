#include "Vector.h"
#include <iostream>
#include <cmath>

Vector::Vector(Number x_, Number y_) : x(x_), y(y_) {}
Vector::Vector(const Vector& other) : x(other.getX()), y(other.getY()) {}
Vector::~Vector() = default;

const Vector Vector::ZERO(Number::ZERO, Number::ZERO);
const Vector Vector::ONE(Number::ONE, Number::ONE);

Number Vector::getX() const { return this->x; }
Number Vector::getY() const { return this->y; }

Number Vector::getPolarRadius() const { 
    return Number::sqrt(this->x * this->x + this->y * this->y); 
}

Number Vector::getPolarAngle() const { 
    return Number(std::atan2(this->y.getValue(), this->x.getValue())); 
}

void Vector::print() const {
    std::cout << "(" << this->x.getValue() << ", " << this->y.getValue() << ")";
}

Vector Vector::operator+(const Vector& other) const { 
    return Vector(this->x + other.getX(), this->y + other.getY()); 
}
