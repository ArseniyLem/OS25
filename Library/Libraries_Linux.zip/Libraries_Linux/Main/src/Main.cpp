#include <iostream>
#include "Vector.h"

int main()
{
    std::cout << "Проверка работы библиотеки Vector:\n\n";

    std::cout << "Проверка перевода координат из декартовой системы в полярную:\n";
    std::cout << "Вектор: ";
    Vector::ONE.print();
    std::cout << " имеет полярные координаты: ";
    std::cout << "радиус " << Vector::ONE.getPolarRadius().getValue() 
              << ", угол " << Vector::ONE.getPolarAngle().getValue();
    std::cout << "\n\n";

    std::cout << "Проверка сложения координат векторов:\n";
    Vector a(Number::create(1), Number::create(2));
    Vector b(Number::create(2), Number::create(3));
    a.print();
    std::cout << " + ";
    b.print();
    std::cout << " = ";
    Vector c = a + b;
    c.print();
    std::cout << "\n";

    return 0;
}
