#include "Number.h"
#include <iostream>
#include <cmath>

Number::Number(double value_) : value(value_) {}
Number::Number(const Number& other) : value(other.getValue()) {}
Number::~Number() = default;
    
double Number::getValue() const { return this->value; }

void Number::print() const {
    std::cout << this->value;
}

const Number Number::ZERO(0.0);
const Number Number::ONE(1.0);

Number Number::operator+(const Number& other) const { return Number(this->value + other.getValue()); }
Number Number::operator-(const Number& other) const { return Number(this->value - other.getValue()); }
Number Number::operator*(const Number& other) const { return Number(this->value * other.getValue()); }
Number Number::operator/(const Number& other) const {
    if (other.value == 0.0) {
        throw std::runtime_error("Division by zero");
    }
    return Number(this->value / other.getValue()); 
}

Number& Number::operator+=(const Number& other) {
    this->value += other.getValue();
    return *this;
}
Number& Number::operator-=(const Number& other){
    this->value -= other.getValue();
    return *this;
}
Number& Number::operator*=(const Number& other) {
    this->value *= other.getValue();
    return *this;
}
Number& Number::operator/=(const Number& other) {
    if (other == ZERO) {
        throw std::runtime_error("Division by zero");
    }
    this->value /= other.getValue();
    return *this;
}

bool Number::operator==(const Number& other) const {
    return this->value == other.getValue();
}
bool Number::operator>(const Number& other) const {
    return this->value > other.getValue();
}
bool Number::operator<(const Number& other) const {
    return this->value < other.getValue();
}
bool Number::operator!=(const Number& other) const {
    return this->value != other.getValue();
}

Number Number::sqrt(const Number number) {
    if (number < ZERO) {
        throw std::runtime_error("Square root of negative number");
    }
    return std::sqrt((number).getValue());
}
Number Number::atan(const Number number) {
    return std::atan(number.getValue());
}

Number Number::create(const double value_) {
    return Number(value_);
}