#include <iostream>
#include <vector>
#include <thread>
#include <chrono>
#include <queue>
#include <functional>
#include <mutex>
#include <condition_variable>
#include <semaphore>
#include <atomic>
#include <barrier>

using namespace std;

struct BlockTaskData {
    const vector<vector<int>>* A;
    const vector<vector<int>>* B;
    vector<vector<int>>* C;

    int rowStart;
    int rowEnd;
    int colStart;
    int colEnd;
    int N;
};

class ThreadPool {
private:
    vector<jthread> workers;
    queue<function<void()>> tasks;
    mutex queueMutex;
    condition_variable taskAdded;
    condition_variable taskCompleted;
    atomic<bool> stop;
    counting_semaphore<8> semaphore{ 8 }; 
    atomic<int> activeTasks{ 0 };

public:
    ThreadPool(size_t numThreads = thread::hardware_concurrency()) : stop(false) {
        for (size_t i = 0; i < numThreads; ++i) {
            workers.emplace_back([this] { workerThread(); });
        }
    }

    ~ThreadPool() {
        stop = true;
        taskAdded.notify_all();
        for (auto& worker : workers) {
            if (worker.joinable()) {
                worker.join();
            }
        }
    }

    void enqueue(function<void()> task) {
        {
            unique_lock<mutex> lock(queueMutex);
            tasks.push(move(task));
            activeTasks++;
        }
        taskAdded.notify_one();
    }

    void waitAll() {
        unique_lock<mutex> lock(queueMutex);
        taskCompleted.wait(lock, [this] { return activeTasks == 0 && tasks.empty(); });
    }

private:
    void workerThread() {
        while (!stop) {
            function<void()> task;

            {
                unique_lock<mutex> lock(queueMutex);
                taskAdded.wait(lock, [this] { return stop || !tasks.empty(); });

                if (stop && tasks.empty()) return;

                task = move(tasks.front());
                tasks.pop();
            }

            semaphore.acquire();

            task();

            semaphore.release();

            {
                lock_guard<mutex> lock(queueMutex);
                activeTasks--;
                if (activeTasks == 0 && tasks.empty()) {
                    taskCompleted.notify_one();
                }
            }
        }
    }
};

void multiplyBlock(BlockTaskData data) {
    for (int i = data.rowStart; i < data.rowEnd; i++) {
        for (int j = data.colStart; j < data.colEnd; j++) {
            int sum = 0;
            for (int k = 0; k < data.N; k++) {
                sum += (*(data.A))[i][k] * (*(data.B))[k][j];
            }
            (*(data.C))[i][j] = sum;
        }
    }
}

void classicMultiply(const vector<vector<int>>& A,
    const vector<vector<int>>& B,
    vector<vector<int>>& C, int N) {

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            int sum = 0;
            for (int k = 0; k < N; k++) {
                sum += A[i][k] * B[k][j];
            }
            C[i][j] = sum;
        }
    }
}

void blockMultiplyWithChannel(const vector<vector<int>>& A,
    const vector<vector<int>>& B,
    vector<vector<int>>& C, int N, int k) {

    ThreadPool pool; 

    for (int i = 0; i < N; i += k) {
        for (int j = 0; j < N; j += k) {

            BlockTaskData data;
            data.A = &A;
            data.B = &B;
            data.C = &C;
            data.rowStart = i;
            data.rowEnd = min(i + k, N);
            data.colStart = j;
            data.colEnd = min(j + k, N);
            data.N = N;

            pool.enqueue([data]() { multiplyBlock(data); });
        }
    }

    pool.waitAll();
}

int main() {
    int N = 6;

    vector<vector<int>> A(N, vector<int>(N));
    vector<vector<int>> B(N, vector<int>(N));
    vector<vector<int>> C(N, vector<int>(N));

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            A[i][j] = rand() % 10;
            B[i][j] = rand() % 10;
        }
    }

    cout << "Matrix size: " << N << "x" << N << endl;
    cout << "Max parallel processes in channel: 8" << endl << endl;

    cout << "Classic multiplication time:\n";
    auto t1 = chrono::high_resolution_clock::now();
    classicMultiply(A, B, C, N);
    auto t2 = chrono::high_resolution_clock::now();
    cout << chrono::duration<double, milli>(t2 - t1).count() << " ms\n\n";

    cout << "Block multiplication with channel (max 8 parallel processes):\n";

    for (int k = 1; k <= N; k++) {
        vector<vector<int>> C2(N, vector<int>(N));

        auto start = chrono::high_resolution_clock::now();
        blockMultiplyWithChannel(A, B, C2, N, k);
        auto end = chrono::high_resolution_clock::now();

        int numBlocks = ((N + k - 1) / k) * ((N + k - 1) / k);
        double ms = chrono::duration<double, milli>(end - start).count();

        cout << "k = " << k << " | blocks = " << numBlocks
            << " | time = " << ms << " ms\n";
    }

    return 0;
}