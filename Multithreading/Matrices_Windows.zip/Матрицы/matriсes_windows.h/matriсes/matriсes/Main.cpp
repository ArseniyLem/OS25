#include <iostream>
#include <vector>
#include <chrono>
#include <windows.h>

using namespace std;

struct BlockTaskData {
    const vector<vector<int>>* A;
    const vector<vector<int>>* B;
    vector<vector<int>>* C;

    int rowStart;
    int rowEnd;
    int colStart;
    int colEnd;
    int N;
};

DWORD WINAPI MultiplyBlock(LPVOID param) {
    BlockTaskData* data = (BlockTaskData*)param;

    for (int i = data->rowStart; i < data->rowEnd; i++) {
        for (int j = data->colStart; j < data->colEnd; j++) {
            int sum = 0;
            for (int k = 0; k < data->N; k++) {
                sum += (*(data->A))[i][k] * (*(data->B))[k][j];
            }
            (*(data->C))[i][j] = sum;
        }
    }

    return 0;
}

void classicMultiply(const vector<vector<int>>& A,
    const vector<vector<int>>& B,
    vector<vector<int>>& C,
    int N)
{
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            int sum = 0;
            for (int k = 0; k < N; k++) {
                sum += A[i][k] * B[k][j];
            }
            C[i][j] = sum;
        }
    }
}

void blockMultiply_WinAPI(const vector<vector<int>>& A,
    const vector<vector<int>>& B,
    vector<vector<int>>& C,
    int N, int k)
{
    vector<HANDLE> threads;
    vector<BlockTaskData*> tasks;

    for (int i = 0; i < N; i += k) {
        for (int j = 0; j < N; j += k) {

            BlockTaskData* task = new BlockTaskData;
            task->A = &A;
            task->B = &B;
            task->C = &C;
            task->rowStart = i;
            task->rowEnd = min(i + k, N);
            task->colStart = j;
            task->colEnd = min(j + k, N);
            task->N = N;

            tasks.push_back(task);

            HANDLE h = CreateThread(nullptr, 0, MultiplyBlock, task, 0, nullptr);
            threads.push_back(h);
        }
    }

    WaitForMultipleObjects(threads.size(), threads.data(), TRUE, INFINITE);

    for (HANDLE h : threads)
        CloseHandle(h);

    for (auto t : tasks)
        delete t;
}

int main() {
    int N = 6; // ����������� 5, ����� ���������
    vector<vector<int>> A(N, vector<int>(N));
    vector<vector<int>> B(N, vector<int>(N));
    vector<vector<int>> C(N, vector<int>(N));

    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            A[i][j] = rand() % 10;
            B[i][j] = rand() % 10;
        }

    cout << "Classic multiplication time:\n";
    auto t1 = chrono::high_resolution_clock::now();
    classicMultiply(A, B, C, N);
    auto t2 = chrono::high_resolution_clock::now();
    cout << chrono::duration<double, milli>(t2 - t1).count() << " ms\n\n";

    cout << "Block multithreading (WinAPI):\n";

    for (int k = 1; k <= N; k++) {
        vector<vector<int>> C2(N, vector<int>(N));

        auto start = chrono::high_resolution_clock::now();
        blockMultiply_WinAPI(A, B, C2, N, k);
        auto end = chrono::high_resolution_clock::now();

        int numBlocks = ((N + k - 1) / k) * ((N + k - 1) / k);
        double ms = chrono::duration<double, milli>(end - start).count();

        cout << "k = " << k
            << " | blocks = " << numBlocks
            << " | time = " << ms << " ms\n";
    }

    return 0;
}
