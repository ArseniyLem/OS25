#include <iostream>
#include <vector>
#include <pthread.h>
#include <chrono>

using namespace std;

struct BlockTaskData {
    const vector<vector<int>>* A;
    const vector<vector<int>>* B;
    vector<vector<int>>* C;
    
    int rowStart;
    int rowEnd;
    int colStart;
    int colEnd;
    int N;
};

void* multiplyBlock(void* arg)
{
    BlockTaskData* data = static_cast<BlockTaskData*>(arg);
    
    for (int i = data->rowStart; i < data->rowEnd; i++) {
        for (int j = data->colStart; j < data->colEnd; j++) {
            int sum = 0;
            for (int k = 0; k < data->N; k++)
                sum += (*(data->A))[i][k] * (*(data->B))[k][j];
            (*(data->C))[i][j] = sum;
        }
    }
    
    return nullptr;
}

void classicMultiply(const vector<vector<int>>& A,
                     const vector<vector<int>>& B,
                     vector<vector<int>>& C, int N)
{
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            int sum = 0;
            for (int k = 0; k < N; k++)
                sum += A[i][k] * B[k][j];
            C[i][j] = sum;
        }
}

void blockMultiply_pthread(const vector<vector<int>>& A,
                           const vector<vector<int>>& B,
                           vector<vector<int>>& C, int N, int k)
{
    // Рассчитываем количество блоков
    int numBlocks = ((N + k - 1) / k) * ((N + k - 1) / k);
    
    // Создаем массив данных для каждого потока
    vector<BlockTaskData> threadData(numBlocks);
    vector<pthread_t> threads(numBlocks);
    
    int blockIndex = 0;
    
    // Создаем потоки для каждого блока
    for (int i = 0; i < N; i += k) {
        for (int j = 0; j < N; j += k) {
            
            threadData[blockIndex].A = &A;
            threadData[blockIndex].B = &B;
            threadData[blockIndex].C = &C;
            threadData[blockIndex].rowStart = i;
            threadData[blockIndex].rowEnd = min(i + k, N);
            threadData[blockIndex].colStart = j;
            threadData[blockIndex].colEnd = min(j + k, N);
            threadData[blockIndex].N = N;
            
            // Создаем поток
            pthread_create(&threads[blockIndex], nullptr, multiplyBlock, &threadData[blockIndex]);
            
            blockIndex++;
        }
    }
    
    // Ждем завершения всех потоков
    for (int i = 0; i < numBlocks; i++) {
        pthread_join(threads[i], nullptr);
    }
}

int main() {
    int N = 6;
    
    vector<vector<int>> A(N, vector<int>(N));
    vector<vector<int>> B(N, vector<int>(N));
    vector<vector<int>> C(N, vector<int>(N));
    
    // Инициализация случайными значениями
    srand(time(nullptr));
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            A[i][j] = rand() % 10;
            B[i][j] = rand() % 10;
        }
    
    cout << "Classic multiplication time:\n";
    auto t1 = chrono::high_resolution_clock::now();
    classicMultiply(A, B, C, N);
    auto t2 = chrono::high_resolution_clock::now();
    cout << chrono::duration<double, milli>(t2 - t1).count() << " ms\n\n";
    
    cout << "Block multithreading (pthread):\n";
    
    for (int k = 1; k <= N; k++) {
        vector<vector<int>> C2(N, vector<int>(N));
        
        auto start = chrono::high_resolution_clock::now();
        blockMultiply_pthread(A, B, C2, N, k);
        auto end = chrono::high_resolution_clock::now();
        
        int numBlocks = ((N + k - 1) / k) * ((N + k - 1) / k);
        double ms = chrono::duration<double, milli>(end - start).count();
        
        cout << "k = " << k << " | blocks = " << numBlocks
             << " | time = " << ms << " ms\n";
    }
    
    return 0;
}
