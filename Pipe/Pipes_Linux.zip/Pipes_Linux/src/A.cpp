#include <iostream>

int main() {
    int x;
    while (std::cin >> x) {
        std::cout << x + 16 << " "; 
    }
    return 0;
}
