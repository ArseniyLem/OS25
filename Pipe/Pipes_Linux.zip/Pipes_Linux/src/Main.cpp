#include <iostream>
#include <string>
#include <vector>
#include <unistd.h>
#include <sys/wait.h>
#include <cstring>

static void Die(const char* msg) {
    perror(msg);
    exit(1);
}

int main() {
    // Создаём пайпы: Main->M, M->A, A->P, P->S, S->Main
    int pipe1[2]; // Main->M
    int pipe2[2]; // M->A
    int pipe3[2]; // A->P
    int pipe4[2]; // P->S
    int pipe5[2]; // S->Main
    
    if (pipe(pipe1) == -1) Die("pipe1 failed");
    if (pipe(pipe2) == -1) Die("pipe2 failed");
    if (pipe(pipe3) == -1) Die("pipe3 failed");
    if (pipe(pipe4) == -1) Die("pipe4 failed");
    if (pipe(pipe5) == -1) Die("pipe5 failed");
    
    // Процесс M
    pid_t pidM = fork();
    if (pidM == 0) {
        // Дочерний процесс M
        close(pipe1[1]); // закрываем конец записи pipe1
        close(pipe2[0]); // закрываем конец чтения pipe2
        
        // Перенаправляем stdin на чтение из pipe1
        dup2(pipe1[0], STDIN_FILENO);
        close(pipe1[0]);
        
        // Перенаправляем stdout на запись в pipe2
        dup2(pipe2[1], STDOUT_FILENO);
        close(pipe2[1]);
        
        // Закрываем все остальные пайпы
        close(pipe3[0]); close(pipe3[1]);
        close(pipe4[0]); close(pipe4[1]);
        close(pipe5[0]); close(pipe5[1]);
        
        // Запускаем M.exe
        execl("./M", "M", nullptr);
        Die("execl M failed");
    }
    
    // Процесс A
    pid_t pidA = fork();
    if (pidA == 0) {
        // Дочерний процесс A
        close(pipe2[1]); // закрываем конец записи pipe2
        close(pipe3[0]); // закрываем конец чтения pipe3
        
        // Перенаправляем stdin на чтение из pipe2
        dup2(pipe2[0], STDIN_FILENO);
        close(pipe2[0]);
        
        // Перенаправляем stdout на запись в pipe3
        dup2(pipe3[1], STDOUT_FILENO);
        close(pipe3[1]);
        
        // Закрываем все остальные пайпы
        close(pipe1[0]); close(pipe1[1]);
        close(pipe4[0]); close(pipe4[1]);
        close(pipe5[0]); close(pipe5[1]);
        
        // Запускаем A.exe
        execl("./A", "A", nullptr);
        Die("execl A failed");
    }
    
    // Процесс P
    pid_t pidP = fork();
    if (pidP == 0) {
        // Дочерний процесс P
        close(pipe3[1]); // закрываем конец записи pipe3
        close(pipe4[0]); // закрываем конец чтения pipe4
        
        // Перенаправляем stdin на чтение из pipe3
        dup2(pipe3[0], STDIN_FILENO);
        close(pipe3[0]);
        
        // Перенаправляем stdout на запись в pipe4
        dup2(pipe4[1], STDOUT_FILENO);
        close(pipe4[1]);
        
        // Закрываем все остальные пайпы
        close(pipe1[0]); close(pipe1[1]);
        close(pipe2[0]); close(pipe2[1]);
        close(pipe5[0]); close(pipe5[1]);
        
        // Запускаем P.exe
        execl("./P", "P", nullptr);
        Die("execl P failed");
    }
    
    // Процесс S
    pid_t pidS = fork();
    if (pidS == 0) {
        // Дочерний процесс S
        close(pipe4[1]); // закрываем конец записи pipe4
        close(pipe5[0]); // закрываем конец чтения pipe5
        
        // Перенаправляем stdin на чтение из pipe4
        dup2(pipe4[0], STDIN_FILENO);
        close(pipe4[0]);
        
        // Перенаправляем stdout на запись в pipe5
        dup2(pipe5[1], STDOUT_FILENO);
        close(pipe5[1]);
        
        // Закрываем все остальные пайпы
        close(pipe1[0]); close(pipe1[1]);
        close(pipe2[0]); close(pipe2[1]);
        close(pipe3[0]); close(pipe3[1]);
        
        // Запускаем S.exe
        execl("./S", "S", nullptr);
        Die("execl S failed");
    }
    
    // Родительский процесс (Main)
    // Закрываем ненужные концы пайпов
    close(pipe1[0]); // Main не читает из pipe1
    close(pipe2[0]); close(pipe2[1]);
    close(pipe3[0]); close(pipe3[1]);
    close(pipe4[0]); close(pipe4[1]);
    close(pipe5[1]); // Main не пишет в pipe5
    
    // Пишем входные данные
    std::string input = "1 2 3\n";
    if (write(pipe1[1], input.c_str(), input.size()) == -1)
        Die("write failed");
    close(pipe1[1]); // Закрываем для отправки EOF
    
    // Читаем результат
    std::cout << "Results: ";
    char buffer[256];
    ssize_t bytes_read;
    while ((bytes_read = read(pipe5[0], buffer, sizeof(buffer) - 1)) > 0) {
        buffer[bytes_read] = '\0';
        std::cout << buffer;
    }
    std::cout << std::endl;
    close(pipe5[0]);
    
    // Ждём завершения всех дочерних процессов
    waitpid(pidM, nullptr, 0);
    waitpid(pidA, nullptr, 0);
    waitpid(pidP, nullptr, 0);
    waitpid(pidS, nullptr, 0);
    
    return 0;
}
