#include <iostream>

int main() {
    int x;
    while (std::cin >> x) {
        std::cout << x * x * x << " ";  // x^3
    }

    return 0;
}