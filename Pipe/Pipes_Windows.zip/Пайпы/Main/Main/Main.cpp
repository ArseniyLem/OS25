﻿#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <iostream>
#include <string>

static void Die(const char* msg) {
    std::cerr << msg << " (GetLastError=" << GetLastError() << ")\n";
    ExitProcess(1);
}

static void MakeInheritable(HANDLE h) {
    if (!SetHandleInformation(h, HANDLE_FLAG_INHERIT, HANDLE_FLAG_INHERIT))
        Die("SetHandleInformation(MakeInheritable) failed");
}

static void MakeNotInheritable(HANDLE h) {
    if (!SetHandleInformation(h, HANDLE_FLAG_INHERIT, 0))
        Die("SetHandleInformation(MakeNotInheritable) failed");
}

static void CreateInheritPipe(HANDLE& r, HANDLE& w) {
    SECURITY_ATTRIBUTES sa{};
    sa.nLength = sizeof(sa);
    sa.bInheritHandle = TRUE;          
    sa.lpSecurityDescriptor = nullptr;

    if (!CreatePipe(&r, &w, &sa, 0))
        Die("CreatePipe failed");
}

static PROCESS_INFORMATION SpawnWithStdHandles(
    const char* exe,
    HANDLE hStdIn,
    HANDLE hStdOut
) {
    STARTUPINFOA si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = hStdIn;
    si.hStdOutput = hStdOut;
    si.hStdError = GetStdHandle(STD_ERROR_HANDLE);

    PROCESS_INFORMATION pi{};
    char cmdLine[MAX_PATH]{};
    strncpy_s(cmdLine, exe, _TRUNCATE);

    if (!CreateProcessA(
        nullptr,
        cmdLine,
        nullptr, nullptr,
        TRUE,          
        0,
        nullptr, nullptr,
        &si, &pi))
        Die("CreateProcess failed");

    return pi;
}

int main() {
    HANDLE p1R, p1W;
    HANDLE p2R, p2W;
    HANDLE p3R, p3W;
    HANDLE p4R, p4W;
    HANDLE p5R, p5W;

    CreateInheritPipe(p1R, p1W);
    CreateInheritPipe(p2R, p2W);
    CreateInheritPipe(p3R, p3W);
    CreateInheritPipe(p4R, p4W);
    CreateInheritPipe(p5R, p5W);

    MakeNotInheritable(p1W); 
    MakeNotInheritable(p5R); 

    auto piM = SpawnWithStdHandles("M.exe", p1R, p2W);
    CloseHandle(p1R);
    CloseHandle(p2W);

    auto piA = SpawnWithStdHandles("A.exe", p2R, p3W);
    CloseHandle(p2R);
    CloseHandle(p3W);

    auto piP = SpawnWithStdHandles("P.exe", p3R, p4W);
    CloseHandle(p3R);
    CloseHandle(p4W);

    auto piS = SpawnWithStdHandles("S.exe", p4R, p5W);
    CloseHandle(p4R);
    CloseHandle(p5W);

    std::string input = "1 2 3\n"; 
    DWORD written = 0;
    if (!WriteFile(p1W, input.data(), (DWORD)input.size(), &written, nullptr))
        Die("WriteFile failed");
    CloseHandle(p1W);

    std::cout << "Results: ";
    char buf[256];
    DWORD rd = 0;
    while (ReadFile(p5R, buf, sizeof(buf) - 1, &rd, nullptr) && rd > 0) {
        buf[rd] = '\0';
        std::cout << buf;
    }
    std::cout << "\n";
    CloseHandle(p5R);

    WaitForSingleObject(piM.hProcess, INFINITE);
    WaitForSingleObject(piA.hProcess, INFINITE);
    WaitForSingleObject(piP.hProcess, INFINITE);
    WaitForSingleObject(piS.hProcess, INFINITE);

    CloseHandle(piM.hProcess); CloseHandle(piM.hThread);
    CloseHandle(piA.hProcess); CloseHandle(piA.hThread);
    CloseHandle(piP.hProcess); CloseHandle(piP.hThread);
    CloseHandle(piS.hProcess); CloseHandle(piS.hThread);

    return 0;
}