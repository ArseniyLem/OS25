#include <windows.h>
#include <iostream>
#include <string>

void runKiller(const std::string& params)
{
    STARTUPINFOA si{};
    PROCESS_INFORMATION pi{};
    si.cb = sizeof(si);

    std::string command = "Killer.exe " + params;
    char cmdLine[256];
    strcpy_s(cmdLine, command.c_str());

    if (CreateProcessA(
        NULL,
        cmdLine,
        NULL,
        NULL,
        FALSE,
        0,
        NULL,
        NULL,
        &si,
        &pi))
    {
        WaitForSingleObject(pi.hProcess, INFINITE);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }
    else
    {
        std::cout << "Failed to start Killer. Error: "
            << GetLastError() << std::endl;
    }
}

int main()
{
    std::string processName;
    DWORD pid;

    std::cout << "Enter process name (e.g. notepad.exe): ";
    std::cin >> processName;

    SetEnvironmentVariableA("PROC_TO_KILL", processName.c_str());
    std::cout << "PROC_TO_KILL set to: " << processName << std::endl;

    system(("start " + processName).c_str());
    Sleep(2000);

    runKiller("--name " + processName);

    std::cout << "\nEnter PID to terminate: ";
    std::cin >> pid;

    runKiller("--id " + std::to_string(pid));

    SetEnvironmentVariableA("PROC_TO_KILL", NULL);
    std::cout << "PROC_TO_KILL removed\n";

    return 0;
}
