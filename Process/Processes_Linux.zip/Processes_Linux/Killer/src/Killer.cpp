#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <sstream>
#include <cstring>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>

// Функция для завершения процесса по PID
bool killByPid(pid_t pid) {
    if (kill(pid, SIGTERM) == 0) {
        std::cout << "Процесс с PID " << pid << " завершён." << std::endl;
        return true;
    } else {
        std::cerr << "Не удалось завершить процесс с PID " << pid << std::endl;
        return false;
    }
}

// Функция для завершения всех процессов с заданным именем
bool killByName(const std::string& name) {
    std::string command = "pkill -f " + name;
    int result = system(command.c_str());
    if (result == 0) {
        std::cout << "Все процессы с именем '" << name << "' завершены." << std::endl;
        return true;
    } else {
        std::cerr << "Не удалось завершить процессы с именем '" << name << "'" << std::endl;
        return false;
    }
}

// Функция для разбиения строки по разделителю
std::vector<std::string> split(const std::string& s, char delimiter) {
    std::vector<std::string> tokens;
    std::string token;
    std::istringstream tokenStream(s);
    while (std::getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

int main(int argc, char* argv[]) {
    // Обработка аргументов командной строки
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--id" && i + 1 < argc) {
            pid_t pid = std::stoi(argv[i + 1]);
            killByPid(pid);
            ++i;
        } else if (arg == "--name" && i + 1 < argc) {
            std::string name = argv[i + 1];
            killByName(name);
            ++i;
        }
    }

    // Проверка переменной окружения PROC_TO_KILL
    const char* procToKill = std::getenv("PROC_TO_KILL");
    if (procToKill != nullptr) {
        std::string procList = procToKill;
        std::vector<std::string> processes = split(procList, ',');
        for (const auto& proc : processes) {
            std::string trimmed = proc;
            // Удаляем возможные пробелы
            trimmed.erase(0, trimmed.find_first_not_of(" \t"));
            trimmed.erase(trimmed.find_last_not_of(" \t") + 1);
            if (!trimmed.empty()) {
                killByName(trimmed);
            }
        }
    }

    return 0;
}
