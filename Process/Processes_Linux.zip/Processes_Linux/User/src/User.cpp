#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <sstream>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <filesystem>  // Для работы с путями

// Функция для проверки существования процесса по PID
bool processExists(pid_t pid) {
    return (kill(pid, 0) == 0);
}

// Функция для проверки существования процесса по имени
bool processExists(const std::string& name) {
    std::string command = "pgrep -f " + name + " > /dev/null 2>&1";
    return (system(command.c_str()) == 0);
}

// Функция для запуска процесса Killer с аргументами
void runKiller(const std::vector<std::string>& args) {
    // Получаем текущую рабочую директорию
    char cwd[1024];
    if (getcwd(cwd, sizeof(cwd)) == NULL) {
        std::cerr << "Ошибка получения текущей директории" << std::endl;
        return;
    }
    
    // Формируем абсолютный путь к Killer
    std::string killerPath = std::string(cwd) + "/build/Killer";
    
    // Проверяем существование файла
    if (access(killerPath.c_str(), X_OK) != 0) {
        std::cerr << "Killer не найден по пути: " << killerPath << std::endl;
        return;
    }
    
    // Формируем команду
    std::string command = killerPath;
    for (const auto& arg : args) {
        command += " " + arg;
    }
    
    std::cout << "Запуск: " << command << std::endl;
    system(command.c_str());
}

int main() {
    // Сначала скомпилируем Killer, если его нет
    std::cout << "Проверка наличия Killer..." << std::endl;
    char cwd[1024];
    getcwd(cwd, sizeof(cwd));
    std::string killerPath = std::string(cwd) + "/build/Killer";
    
    if (access(killerPath.c_str(), X_OK) != 0) {
        std::cout << "Killer не найден. Попытка компиляции..." << std::endl;
        std::string compileCmd = "g++ -std=c++11 -o build/Killer Killer/src/Killer.cpp";
        if (system(compileCmd.c_str()) != 0) {
            std::cerr << "Ошибка компиляции Killer!" << std::endl;
            return 1;
        }
    }

    // Установка переменной окружения PROC_TO_KILL
    std::string procToKill = "telegram";
    setenv("PROC_TO_KILL", procToKill.c_str(), 1);

    std::cout << "Установлена переменная PROC_TO_KILL: " << procToKill << std::endl;

    // Запускаем тестовые процессы для демонстрации
    std::cout << "\nЗапуск тестовых процессов sleep..." << std::endl;
    system("sleep 300 &");
    system("sleep 400 &");
    sleep(1); // Даем время процессам запуститься

    // Демонстрация завершения по имени
    std::cout << "\n1. Завершение процессов по имени:" << std::endl;
    std::string testProcessName = "sleep";
    if (processExists(testProcessName)) {
        std::cout << "Процесс с именем '" << testProcessName << "' существует." << std::endl;
        runKiller({"--name", testProcessName});
        sleep(1); // Даем время на завершение
        if (!processExists(testProcessName)) {
            std::cout << "Процесс успешно завершён." << std::endl;
        } else {
            std::cout << "Процесс всё ещё существует." << std::endl;
        }
    } else {
        std::cout << "Процесс с именем '" << testProcessName << "' не найден." << std::endl;
    }

    // Демонстрация завершения по PID
    std::cout << "\n2. Завершение процесса по PID:" << std::endl;
    pid_t testPid = getpid(); // текущий процесс
    std::cout << "Текущий PID: " << testPid << std::endl;
    if (processExists(testPid)) {
        std::cout << "Процесс с PID " << testPid << " существует." << std::endl;
        // Не будем завершать себя, а завершим другой процесс
        pid_t childPid = fork();
        if (childPid == 0) {
            // Дочерний процесс
            sleep(500);
            exit(0);
        } else {
            // Родительский процесс
            sleep(1);
            std::cout << "Завершаем дочерний процесс с PID " << childPid << std::endl;
            runKiller({"--id", std::to_string(childPid)});
            sleep(1);
            if (!processExists(childPid)) {
                std::cout << "Дочерний процесс успешно завершён." << std::endl;
            }
        }
    }

    // Демонстрация завершения через переменную окружения
    std::cout << "\n3. Завершение процессов через PROC_TO_KILL:" << std::endl;
    // Запустим процесс с именем из списка для теста
    system("sleep 600 &");
    setenv("PROC_TO_KILL", "sleep,test", 1);
    runKiller({});

    // Удаление переменной окружения
    unsetenv("PROC_TO_KILL");
    std::cout << "\nПеременная PROC_TO_KILL удалена." << std::endl;

    // Завершаем все оставшиеся sleep процессы
    system("pkill -f sleep 2>/dev/null");

    return 0;
}
